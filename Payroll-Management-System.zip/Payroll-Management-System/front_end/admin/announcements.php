<?php
/**
 * Redirect to announcement.php (singular)
 * This file exists for backward compatibility
 */
header('Location: announcement.php');
exit;
